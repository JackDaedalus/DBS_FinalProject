import pandas as pd

def azureml_main(dataframe1 = None, dataframe2 = None):
    print(dataframe1.head())
    
    return dataframe1,
