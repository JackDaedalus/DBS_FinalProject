
A project application is available for demonstration at : https://ciaran-finnegan.shinyapps.io/DBS_CCFraudRShinyApp_10524150/

The project requires that sample 'new' transactions are stored locally. These files can be found in the root folder in the file: You_Must_Install_These_Files_Locally.zip.

The User Guide for this prototype is included in this submission in the file : /UserGuide/10524150_DBSFinalProject_UserGuide cf v1-1 210920.pptx

All other project information compiled to date is in the Final Report document in the /Report sub-folder.