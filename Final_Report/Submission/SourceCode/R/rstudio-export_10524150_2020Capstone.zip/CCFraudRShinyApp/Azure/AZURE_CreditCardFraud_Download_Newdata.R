
## Higher Diploma in Science in Data Analytics : Project : Module Code B8IT110
## Student Name : Ciaran Finnegan

## Student Number : 10524150

## August / September 2020


## This file contains the R code to invoke the API to load Azure hosted
## credit card datasets

## It is separated out from the main 'app.R' file because the project
## has split source code into modules to avoid the main Shiny application
## file from growing too large. (This attempts to make the code more
## readable).


## These routines directly read credit card transaction datasets that are stored
## in Azure. This allows for greater ease of deployment of the application and
## more effective automatic access to the datasets 


##  --  These libraries were required during RStudio environment set up -- ##
##devtools::install_github("RevolutionAnalytics/AzureML")
##install.packages("AzureML")
##library(AzureML)
## ----------------------------------------------------------------------- ##




## This function returns the credit card transaction dataset that was used for the
## creation of the final trained predictive model for fraudulent credit card transactions
## This function drives all of the data visualization graphs on the 1st tab with the 
## exception of the 100% Stacked Bar chart.
download25KProductionCCTxns= function(){
  
  import("AzureML")
  

  ws <- workspace(
    id = "7375a43f744940748c691a78945b2588",
    auth = "hItFXmJqT2qV4rYUREXnnfy5ZfleIiXBiQB8q1bA1zfF53dcJJP4CwqXvgy2Wls/QpAhX0jEqzaLNWqjMfKDTQ==",
    api_endpoint = "https://europewest.studioapi.azureml.net"
  )
  ds <- download.datasets(
    dataset = ws,
    name = "CreditCard_Fraud_Cleaned_Dataset_EDA_25KRows_Sept_v1_2020.csv",
    fill = TRUE
  )
  
  return(ds)
  
  
}



## This function loads data that has been manipulated to enhance the 25K row dataset with an grouping 
## for geographical locations
## The data is used for the 100% Stacked Bar Chart breakdown for Fraud across differnt regions.
downloadDevCntryCdCCTxns = function() {
  
  import("AzureML")
  
  
  ws <- workspace(
    id = "7375a43f744940748c691a78945b2588",
    auth = "hItFXmJqT2qV4rYUREXnnfy5ZfleIiXBiQB8q1bA1zfF53dcJJP4CwqXvgy2Wls/QpAhX0jEqzaLNWqjMfKDTQ==",
    api_endpoint = "https://europewest.studioapi.azureml.net"
  )
  ds <- download.datasets(
    dataset = ws,
    name = "CreditCard_Fraud_CountryCode_Cleaned_Dataset_EDA_25KRows_Sept_v1_2020.csv"
  )
  
  
  return(ds)
  
}










