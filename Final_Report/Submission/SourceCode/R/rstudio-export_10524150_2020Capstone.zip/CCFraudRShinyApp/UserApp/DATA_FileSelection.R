## Higher Diploma in Science in Data Analytics : Project : Module Code B8IT110
## Student Name : Ciaran Finnegan

## Student Number : 10524150

## September 2020

## This file contains the Shiny code to limit display values for a 'selected
## transaction'.

## It is separated out from the main 'app.R' file because the project
## has split source code into modules to avoid the main Shiny application
## file from growing too large. (This attempts to make the code more
## readable).



## This function is a further restriction on the feature list displayed on screen
## It is used when a credit card transaction is selected from the main list on the
## Fraud UI tab and the details of that selection are reproduced in the single line
## 'selected transaction' table.
## The feature list is reduced so that information for the transction fits on screen 
## without the need for a scroll bar.
SelectColumsToHide = function(cc_Txns){
  
  # Restrict Display on single view of a selected credit card transaction
  # Done to improve on screen display and navigation
  
  
  # Choose Columns NOT to Display
  select_cols = c(
    'AccountSourceUniqueId',
    'MerchantCategory',
    'AcquirerRefId',
    'AuthId',
    'DvcVerificationCap',
    'DeviceCountryCode',
    'HighRiskPOSCnt.cnt.hour.present',
    'FuelPumpCount.cnt.day.total',
    'FuelPumpCount.cnt.day.present',
    'NotECommerceAuthAmount.acc.day.past3',
    'NonEMVTransactionsCount.cnt.day.past29',
    'POSTerminalAttendedAuthCount.cnt.day.past3',
    'DomesticAuthCount.cnt.hour1',
    'NotECommerceAuthCount.cnt.day.present',
    'EMVTransactionsCount.cnt.day.present',
    'EMVTransactionsCount.cnt.day.past3',
    'POS_Count.cnt.day.present',
    'EMVTransactionsAcc.acc.day.past1',
    'AlternatingCountrySwapCounter.cnt.day.past1')
  
  
  # Passed back list of columns are then used as a parameter to a datatableproxy function
  columns2hide <- match(select_cols, colnames(cc_Txns))
  
  
  
}