## Higher Diploma in Science in Data Analytics : Project : Module Code B8IT110
## Student Name : Ciaran Finnegan

## Student Number : 10524150

## September 2020

## This file contains the Shiny code for File Select on the dashboard.
## It is separated out from the main 'app.R' file because the project
## has split source code into modules to avoid the main Shiny application
## file from growing too large. (This attempts to make the code more
## readable).






## This function is called within the main 'csvFileServer' function 
## It is a wrapper function to filter the contents of the loaded csv file
## The function works of a list of feature names and only these values
## are passed into a data frame for use in the main application.

## These features are the 28 features selected for use by the trained
## predictive fraud model. Any other data in the csv file is unnecessary
funcExtractSelectedFeaturesfromFile = function(input_ds) {

  # Set up the columns that are intended for display
  # and to be passed to the Fraud API
  myvars <- c(
        'Fraud',
        'AccountSourceUniqueId',
        'CardSourceRefId',
        'MerchantCategory',
        'AcquirerRefId',
        'AuthId',
        'AmountOrig',
        'CardType',
        'DvcVerificationCap',
        'CustomerPresentIndicator',
        'PosTerminalAttended',
        'DeviceZone',
        'DeviceCountryCode',
        'ECommerceFlag',
        'PinIndicator',
        'HighRiskPOSCnt.cnt.hour.present',
        'FuelPumpCount.cnt.day.total',
        'FuelPumpCount.cnt.day.present',
        'NotECommerceAuthAmount.acc.day.past3',
        'NonEMVTransactionsCount.cnt.day.past29',
        'POSTerminalAttendedAuthCount.cnt.day.past3',
        'DomesticAuthCount.cnt.hour1',
        'NotECommerceAuthCount.cnt.day.present',
        'EMVTransactionsCount.cnt.day.present',
        'EMVTransactionsCount.cnt.day.past3',
        'POS_Count.cnt.day.present',
        'EMVTransactionsAcc.acc.day.past1',
        'AlternatingCountrySwapCounter.cnt.day.past1'
      )

  newdata <- input_ds[myvars]
  newdata

}



# Module UI function for File Select on Dashboard tab
csvFileUI <- function(id, label = "\n") {
  # `NS(id)` returns a namespace function, which was save as `ns` and will
  # invoke later.
  ns <- NS(id)
  
  tagList(
    fileInput(ns("file"), label, accept = ".csv",  width = '400px',
              buttonLabel = "Click here to select file...")
  )
}



# Module server function for File Select on Dashboard tab
csvFileServer <- function(id, stringsAsFactors) {
  moduleServer(
    id,
    ## Below is the module function
    function(input, output, session) {
      # The selected file, if any
      userFile <- reactive({
        # If no file is selected, don't do anything
        validate(need(input$file, message = FALSE))
        input$file
      })
      
      # The user's data, parsed into a data frame
      # This is wrapped within another function that filters only the required 
      # credit card transaction features from the file
      dataframe <- reactive({
        funcExtractSelectedFeaturesfromFile(
                read.csv(userFile()$datapath,
                stringsAsFactors = stringsAsFactors)
        )
      })
      
      # We can run observers in here if we want to
      observe({
        msg <- sprintf("\n\nFile %s was uploaded", userFile()$name)
        cat(msg, "\n")
      })
      
      #cc_trxn_file_ds <- funcExtractSelectedFeaturesfromFile(dataframe)
      cc_trxn_file_ds <- dataframe
      
      # Return the reactive that yields the data frame
      return(cc_trxn_file_ds)  #return(dataframe)
    }
  )    
}

