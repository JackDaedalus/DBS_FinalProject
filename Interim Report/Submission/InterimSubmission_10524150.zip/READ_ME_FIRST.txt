
A Prototype application is available for demonstration at : https://ciaran-finnegan.shinyapps.io/DBS_CCFraudRShinyApp_10524150/

The User Guide for this prototype is included in this submission in the file : 10524150_DBSFinalProject_PrototypeUserGuide cf v1-2 140820.pptx

All other project information compiled to date is in the Interim Report document.